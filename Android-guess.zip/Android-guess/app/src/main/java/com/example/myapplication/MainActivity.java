package com.example.myapplication;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.text.Editable;
import android.text.TextWatcher;
import android.util.Log;
import android.view.View;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;
import java.util.Random;
public class MainActivity extends AppCompatActivity {
    private EditText mEditText;
    private ImageView iv;
    private boolean canCheck = false;
    int targetNum;
    @Override
    protected void onCreate(Bundle savedInstanceState) {

        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        Random rd = new Random();
        targetNum = rd.nextInt(10000);
        System.out.println(targetNum);
        mEditText = (EditText) findViewById(R.id.num);
        addListen();
    }

    public void check (View view){

        if(canCheck){
            int n = Integer.parseInt(mEditText.getText().toString());
            setContentView(R.layout.result);
            System.out.println(n);
            System.out.println(targetNum);
            TextView numStr = findViewById(R.id.numStr);
            numStr.setText(mEditText.getText().toString());
            if(n > targetNum) {
                ImageView iv = findViewById(R.id.up);
                iv.setImageResource(R.mipmap.uplight);
                System.out.println("N > num");

            }else if(n < targetNum){
                ImageView iv = findViewById(R.id.down);
                iv.setImageResource(R.mipmap.downlight);
                System.out.println("N < num");
            }else{
                ImageView ivUp = findViewById(R.id.up);
                ImageView ivDown = findViewById(R.id.down);
                ImageView face = findViewById(R.id.face);
                TextView tv = findViewById(R.id.resultText);
                System.out.println("N = num");
                tv.setText("You got it!");
                tv.setTextColor(getResources().getColor(R.color.colorAccent));
                ivUp.setVisibility(View.INVISIBLE);
                ivDown.setVisibility(View.INVISIBLE);
                face.setImageResource(R.mipmap.smile);
                Random rd = new Random();
                targetNum = rd.nextInt(10000);
            }

        }
    }


    public static boolean isNumeric(String str){
        if(str.length() == 0)return false;
        for (int i = 0; i < str.length(); i++){
            if (!Character.isDigit(str.charAt(i))){
                return false;
            }
        }
        return true;
    }

    private void addListen(){
        mEditText = (EditText) findViewById(R.id.num);
        mEditText.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence s, int start, int count, int after) {

            }

            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) {
                String num = mEditText.getText().toString();
                if (isNumeric(num) && num.length() > 0 && num.length() <= 4){

                    iv = findViewById(R.id.checkBtn);
                    //更改图片
                    iv.setImageResource(R.mipmap.able);
                    canCheck = true;


                }else {
                    canCheck = false;
                    iv.setImageResource(R.mipmap.unable);
                }


            }

            @Override
            public void afterTextChanged(Editable s) {

            }
        });
    }
    public void reGuess(View view) {
        setContentView(R.layout.activity_main);
        addListen();
    }
}
